#!/usr/bin/env bash
# Reproduce every result, table and figure in the manuscript.
# Usage: bash run_all.sh path/to/merged_molecular_descriptors_columns_renamed.csv
set -euo pipefail
CSV="${1:-merged_molecular_descriptors_columns_renamed.csv}"
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$HERE/results"; FIG="$HERE/figures"
mkdir -p "$OUT" "$FIG"
cd "$HERE/python"

# 1. Supervised LOOCV benchmark: 39 techniques x 17 metrics, real + seed-42 null (~2 min)
python amino_acid_pipeline_v4.py --input "$CSV" --outdir "$OUT"
# 2. 100-seed null-control replicate (~45 min on 2 cores; scale --n-jobs to your machine)
python amino_acid_pipeline_v4.py --input "$CSV" --outdir "$OUT" --null-seeds 0-99 --n-jobs 2
# 3. Clustering, validation, permutation, consensus, Kruskal-Wallis, ablation, descriptive analyses (~30 s)
python amino_acid_unsupervised_v4.py --input "$CSV" --outdir "$OUT"
# 4. Figures 1-12 (PNG 300 dpi, TIFF 600 dpi, PDF)
python make_figures_v4.py --input "$CSV" --results "$OUT" --figdir "$FIG"
# 5. Parallel R workflow (cross-checks against the Python results in $OUT)
if command -v Rscript >/dev/null 2>&1; then
  Rscript "$HERE/R/amino_acid_workflow.R" "$CSV" "$OUT" "$HERE/results_R"
else
  echo "Rscript not found: skipping the R workflow"
fi
