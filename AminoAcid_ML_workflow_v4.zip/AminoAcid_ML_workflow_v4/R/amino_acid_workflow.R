#!/usr/bin/env Rscript
# =============================================================================
# amino_acid_workflow.R
# Parallel R implementation of the amino acid descriptor analysis
# (companion to the Python workflow: amino_acid_pipeline_v4.py,
#  amino_acid_unsupervised_v4.py, make_figures_v4.py)
#
# What this script reproduces
#   A. Unsupervised cross-check (Tables 1-5): cophenetic correlation, internal
#      indices (silhouette, Calinski-Harabasz, Davies-Bouldin), external indices
#      (ARI, NMI, AMI, V-measure, homogeneity, completeness, Fowlkes-Mallows),
#      label permutation test, bootstrap consensus clustering, Kruskal-Wallis +
#      Benjamini-Hochberg screen, descriptor-block ablation, descriptive PCA.
#   B. Supervised LOOCV cross-check with per-fold standardisation + PCA(19) for
#      the deterministic techniques whose R implementations are numerically
#      equivalent to scikit-learn: distance-weighted kNN (k = 3), kNN (k = 1, 3, 5),
#      nearest centroid, Gaussian naive Bayes, and linear-kernel SVC (libsvm via
#      e1071, the same library scikit-learn's SVC wraps).
#      Run on the real descriptors and on the seed-42 null matrix exported by the
#      Python pipeline (null_seed42_matrix.csv), so both languages analyse the
#      identical null matrix.
#
# Expected agreement with Python
#   * Deterministic quantities (Tables 1, 2, 4 for hierarchical solutions, 5;
#     Kruskal-Wallis counts and minimum q; PCA variance; kNN / nearest-centroid /
#     GaussianNB / linear SVC LOOCV metrics) should agree to rounding.
#   * Quantities that depend on a random number stream (permutation p-value,
#     bootstrap consensus) use R's Mersenne-Twister with set.seed(42); they will
#     agree in magnitude and conclusion but not digit-for-digit with numpy.
#
# Usage
#   Rscript amino_acid_workflow.R <merged.csv> <python_results_dir> <out_dir>
#
# Required CRAN packages: cluster, e1071 (install.packages(c("cluster","e1071")))
# Tested design target: R >= 4.3.
# =============================================================================

suppressPackageStartupMessages({
  library(cluster)
  library(e1071)
})

args <- commandArgs(trailingOnly = TRUE)
csv_path  <- if (length(args) >= 1) args[1] else "merged_molecular_descriptors_columns_renamed.csv"
py_dir    <- if (length(args) >= 2) args[2] else "results"
out_dir   <- if (length(args) >= 3) args[3] else "results_R"
dir.create(out_dir, showWarnings = FALSE, recursive = TRUE)

# -----------------------------------------------------------------------------
# 0. Data and ground-truth labels (Lehninger five-class scheme)
# -----------------------------------------------------------------------------
class_map <- c(
  "Glycine" = "Nonpolar_Aliphatic", "Alanine" = "Nonpolar_Aliphatic",
  "Valine" = "Nonpolar_Aliphatic", "Leucine" = "Nonpolar_Aliphatic",
  "Isoleucine" = "Nonpolar_Aliphatic", "Methionine" = "Nonpolar_Aliphatic",
  "Proline" = "Nonpolar_Aliphatic",
  "Phenylalanine" = "Aromatic", "Tyrosine" = "Aromatic", "Tryptophan" = "Aromatic",
  "Serine" = "Polar_Uncharged", "Threonine" = "Polar_Uncharged",
  "Cysteine" = "Polar_Uncharged", "Asparagine" = "Polar_Uncharged",
  "Glutamine" = "Polar_Uncharged",
  "Lysine" = "Positively_Charged", "Arginine" = "Positively_Charged",
  "Histidine" = "Positively_Charged",
  "Aspartic Acid" = "Negatively_Charged", "Glutamic Acid" = "Negatively_Charged")
one_letter <- c("Alanine" = "A", "Arginine" = "R", "Asparagine" = "N", "Aspartic Acid" = "D",
                "Cysteine" = "C", "Glutamic Acid" = "E", "Glutamine" = "Q", "Glycine" = "G",
                "Histidine" = "H", "Isoleucine" = "I", "Leucine" = "L", "Lysine" = "K",
                "Methionine" = "M", "Phenylalanine" = "F", "Proline" = "P", "Serine" = "S",
                "Threonine" = "T", "Tryptophan" = "W", "Tyrosine" = "Y", "Valine" = "V")

df <- read.csv(csv_path, check.names = FALSE, stringsAsFactors = FALSE)
desc_cols <- setdiff(names(df), c("Amino_Acid", "Symbol"))
X <- as.matrix(sapply(df[, desc_cols], as.numeric))
stopifnot(!anyNA(X), all(df$Amino_Acid %in% names(class_map)))
classes <- sort(unique(unname(class_map)), method = "radix")   # alphabetical (locale-independent), as in Python
y <- factor(class_map[df$Amino_Acid], levels = classes)
yi <- as.integer(y)                                      # 1..5
letters_aa <- unname(one_letter[df$Amino_Acid])
n <- nrow(X); p <- ncol(X); K <- length(classes)
cat(sprintf("n = %d amino acids, p = %d descriptors, constant columns = %d\n",
            n, p, sum(apply(X, 2, sd) == 0)))

# population-SD standardisation (identical to scikit-learn StandardScaler)
zscore <- function(M, center = colMeans(M),
                   scale = sqrt(colMeans(sweep(M, 2, colMeans(M))^2))) {
  scale[scale == 0] <- 1
  sweep(sweep(M, 2, center, "-"), 2, scale, "/")
}
Z <- zscore(X)

# -----------------------------------------------------------------------------
# 1. Clustering indices
# -----------------------------------------------------------------------------
ch_index <- function(Z, lab) {             # Calinski-Harabasz (Euclidean)
  k <- length(unique(lab)); n <- nrow(Z); g <- colMeans(Z)
  B <- 0; W <- 0
  for (c in unique(lab)) {
    Zc <- Z[lab == c, , drop = FALSE]; mc <- colMeans(Zc)
    B <- B + nrow(Zc) * sum((mc - g)^2); W <- W + sum(sweep(Zc, 2, mc)^2)
  }
  (B / (k - 1)) / (W / (n - k))
}
db_index <- function(Z, lab) {             # Davies-Bouldin (scikit-learn definition)
  cl <- sort(unique(lab))
  cent <- t(sapply(cl, function(c) colMeans(Z[lab == c, , drop = FALSE])))
  s <- sapply(seq_along(cl), function(i) {
    Zc <- Z[lab == cl[i], , drop = FALSE]; mean(sqrt(rowSums(sweep(Zc, 2, cent[i, ])^2)))
  })
  Dc <- as.matrix(dist(cent))
  mean(sapply(seq_along(cl), function(i) max((s[i] + s[-i]) / Dc[i, -i])))
}
sil <- function(Z, lab, method = "manhattan") mean(silhouette(lab, dist(Z, method))[, "sil_width"])

# --- external indices --------------------------------------------------------
entropy <- function(v) { p <- table(v) / length(v); -sum(p * log(p)) }
mutual_info <- function(a, b) {
  t <- table(a, b) / length(a); pa <- rowSums(t); pb <- colSums(t)
  nz <- t > 0; sum(t[nz] * log(t[nz] / outer(pa, pb)[nz]))
}
expected_mi <- function(a, b) {            # Vinh, Epps & Bailey (2010)
  N <- length(a); A <- as.numeric(table(a)); B <- as.numeric(table(b)); emi <- 0
  for (ai in A) for (bj in B) {
    lo <- max(1, ai + bj - N); hi <- min(ai, bj)
    if (lo > hi) next
    for (nij in lo:hi) {
      lp <- lchoose(bj, nij) + lchoose(N - bj, ai - nij) - lchoose(N, ai)   # hypergeometric
      emi <- emi + (nij / N) * log(N * nij / (ai * bj)) * exp(lp)
    }
  }
  emi
}
ari <- function(a, b) {
  t <- table(a, b); sc <- sum(choose(t, 2)); sa <- sum(choose(rowSums(t), 2))
  sb <- sum(choose(colSums(t), 2)); e <- sa * sb / choose(length(a), 2)
  (sc - e) / (0.5 * (sa + sb) - e)
}
external <- function(truth, lab) {
  ha <- entropy(truth); hb <- entropy(lab); mi <- mutual_info(truth, lab)
  hom <- if (ha == 0) 1 else mi / ha; com <- if (hb == 0) 1 else mi / hb
  t <- table(truth, lab); tk <- sum(t^2) - length(truth)
  pk <- sum(colSums(t)^2) - length(truth); qk <- sum(rowSums(t)^2) - length(truth)
  emi <- expected_mi(truth, lab)
  c(ARI = ari(truth, lab), NMI = mi / ((ha + hb) / 2),
    AMI = (mi - emi) / ((ha + hb) / 2 - emi),
    V_measure = 2 * hom * com / (hom + com), Homogeneity = hom, Completeness = com,
    Fowlkes_Mallows = tk / sqrt(pk * qk))
}

# -----------------------------------------------------------------------------
# 2. Table 1: cophenetic correlation by linkage
# -----------------------------------------------------------------------------
dM <- dist(Z, "manhattan"); dE <- dist(Z, "euclidean")
cfg <- list(c("ward.D2", "euclidean"), c("average", "manhattan"), c("average", "euclidean"),
            c("complete", "manhattan"), c("single", "manhattan"))
t1 <- do.call(rbind, lapply(cfg, function(cc) {
  d <- if (cc[2] == "manhattan") dM else dE
  h <- hclust(d, method = cc[1])
  data.frame(method = cc[1], metric = cc[2], cophenetic = cor(cophenetic(h), d))
}))
print(t1, digits = 4); write.csv(t1, file.path(out_dir, "R_table1_cophenetic.csv"), row.names = FALSE)

# -----------------------------------------------------------------------------
# 3. Table 2: internal validation, k = 2..5 (average linkage, Manhattan)
# -----------------------------------------------------------------------------
h_avg <- hclust(dM, method = "average")
t2 <- do.call(rbind, lapply(2:5, function(k) {
  lab <- cutree(h_avg, k)
  data.frame(k = k, Silhouette_Manhattan = sil(Z, lab), Silhouette_Euclidean = sil(Z, lab, "euclidean"),
             Calinski_Harabasz = ch_index(Z, lab), Davies_Bouldin = db_index(Z, lab),
             ARI = ari(yi, lab))
}))
print(t2, digits = 4); write.csv(t2, file.path(out_dir, "R_table2_internal_k.csv"), row.names = FALSE)
hc2 <- cutree(h_avg, 2); hc5 <- cutree(h_avg, 5)
cat("Two-cluster membership:\n"); print(split(letters_aa, hc2))

# -----------------------------------------------------------------------------
# 4. Table 4: external validation of hierarchical solutions
#    (k-means / GMM / spectral use library-specific random initialisations and
#     are reproduced in Python only; see amino_acid_unsupervised_v4.py)
# -----------------------------------------------------------------------------
t4 <- rbind(`Hierarchical (k=2)` = external(yi, hc2), `Hierarchical (k=5)` = external(yi, hc5))
print(round(t4, 4)); write.csv(t4, file.path(out_dir, "R_table4_external_hc.csv"))

# -----------------------------------------------------------------------------
# 5. Label permutation test (2,000 permutations)
# -----------------------------------------------------------------------------
set.seed(42)
obs <- ari(yi, hc2)
null_ari <- replicate(2000, ari(sample(yi), hc2))
perm <- c(observed_ARI = obs, null_mean = mean(null_ari),
          null_p95 = unname(quantile(null_ari, 0.95)),
          p_value = (1 + sum(null_ari >= obs)) / (1 + 2000))
print(round(perm, 4))

# -----------------------------------------------------------------------------
# 6. Bootstrap consensus clustering (100 iterations, 80% subsampling,
#    re-standardised within each subsample)
# -----------------------------------------------------------------------------
set.seed(42)
Mx <- matrix(0, n, n); Cn <- matrix(0, n, n)
for (b in 1:100) {
  idx <- sort(sample.int(n, 16))
  lab <- cutree(hclust(dist(zscore(X[idx, ]), "manhattan"), "average"), 2)
  Mx[idx, idx] <- Mx[idx, idx] + outer(lab, lab, "==")
  Cn[idx, idx] <- Cn[idx, idx] + 1
}
Kc <- Mx / pmax(Cn, 1); dimnames(Kc) <- list(letters_aa, letters_aa)
ut <- upper.tri(Kc)
aro <- c(Kc["F", "W"], Kc["F", "Y"], Kc["W", "Y"])
cat(sprintf("Consensus: mean over pairs = %.4f; aromatic = %.4f +/- %.4f; R-K = %.3f\n",
            mean(Kc[ut]), mean(aro), sqrt(mean((aro - mean(aro))^2)), Kc["R", "K"]))
write.csv(Kc, file.path(out_dir, "R_consensus_matrix.csv"))

# -----------------------------------------------------------------------------
# 7. Kruskal-Wallis screen + Benjamini-Hochberg FDR
# -----------------------------------------------------------------------------
kw_p <- apply(X, 2, function(v) {
  pv <- tryCatch(kruskal.test(v, y)$p.value, error = function(e) NA_real_)
  if (is.na(pv)) 1 else pv
})
kw_q <- p.adjust(kw_p, method = "BH")
cat(sprintf("Kruskal-Wallis: %d nominal p < 0.05 (%.1f%%); %d with BH q < 0.05; min q = %.6f\n",
            sum(kw_p < 0.05), 100 * mean(kw_p < 0.05), sum(kw_q < 0.05), min(kw_q)))
write.csv(data.frame(descriptor = desc_cols, p = kw_p, q_BH = kw_q),
          file.path(out_dir, "R_kruskal_wallis.csv"), row.names = FALSE)

# -----------------------------------------------------------------------------
# 8. Table 5: descriptor-block ablation (d1-d22 graph block vs d23-d6977)
# -----------------------------------------------------------------------------
blocks <- list(`Graph theoretic only (d1-d22)` = 1:22,
               `Physicochemical only (d23-d6977)` = 23:p, `Combined / unified` = 1:p)
t5 <- do.call(rbind, lapply(names(blocks), function(b) {
  Zb <- zscore(X[, blocks[[b]], drop = FALSE]); d <- dist(Zb, "manhattan"); h <- hclust(d, "average")
  data.frame(block = b, n_features = length(blocks[[b]]), cophenetic = cor(cophenetic(h), d),
             ARI_k2 = ari(yi, cutree(h, 2)), ARI_k5 = ari(yi, cutree(h, 5)))
}))
print(t5, digits = 4); write.csv(t5, file.path(out_dir, "R_table5_ablation.csv"), row.names = FALSE)

# -----------------------------------------------------------------------------
# 9. Descriptive PCA (Figures 1-2)
# -----------------------------------------------------------------------------
pc <- prcomp(Z, center = FALSE, scale. = FALSE)
evr <- pc$sdev^2 / sum(pc$sdev^2)
cat(sprintf("PCA: PC1 = %.1f%%, PC2 = %.1f%%, components for 90%% = %d\n",
            100 * evr[1], 100 * evr[2], which(cumsum(evr) >= 0.9)[1]))
write.csv(data.frame(aa = letters_aa, PC1 = pc$x[, 1], PC2 = pc$x[, 2]),
          file.path(out_dir, "R_pca_scores.csv"), row.names = FALSE)

# -----------------------------------------------------------------------------
# 10. Supervised LOOCV cross-check (per-fold StandardScaler -> PCA(19) -> model)
# -----------------------------------------------------------------------------
fold_pca <- function(Xtr, Xte, ncomp = 19) {
  mu <- colMeans(Xtr); s <- sqrt(colMeans(sweep(Xtr, 2, mu)^2)); s[s == 0] <- 1
  Ztr <- sweep(sweep(Xtr, 2, mu), 2, s, "/"); Zte <- sweep(sweep(Xte, 2, mu), 2, s, "/")
  # PCA via SVD of the centred training matrix (columns already centred)
  sv <- svd(Ztr, nu = 0, nv = ncomp)
  list(tr = Ztr %*% sv$v, te = Zte %*% sv$v)
}
knn_predict <- function(tr, ytr, te, k, weighted = FALSE) {
  d <- sqrt(colSums((t(tr) - as.numeric(te))^2))
  o <- order(d)[1:k]
  if (weighted) {
    if (any(d[o] == 0)) return(ytr[o][d[o] == 0][1])
    w <- tapply(1 / d[o], factor(ytr[o], levels = 1:K), sum)
  } else {
    w <- tabulate(ytr[o], nbins = K)
  }
  w[is.na(w)] <- 0
  which.max(w)                    # ties -> lowest class index, as in scikit-learn
}
centroid_predict <- function(tr, ytr, te) {
  cen <- t(sapply(1:K, function(c) colMeans(tr[ytr == c, , drop = FALSE])))
  which.min(colSums((t(cen) - as.numeric(te))^2))
}
gnb_predict <- function(tr, ytr, te) {           # scikit-learn GaussianNB, var_smoothing = 1e-9
  eps <- 1e-9 * max(apply(tr, 2, function(v) mean((v - mean(v))^2)))
  ll <- sapply(1:K, function(c) {
    Tc <- tr[ytr == c, , drop = FALSE]; mu <- colMeans(Tc)
    v <- colMeans(sweep(Tc, 2, mu)^2) + eps
    log(mean(ytr == c)) - 0.5 * sum(log(2 * pi * v)) - 0.5 * sum((as.numeric(te) - mu)^2 / v)
  })
  which.max(ll)
}
svc_predict <- function(tr, ytr, te) {           # libsvm C-SVC, linear kernel, C = 1
  m <- svm(x = tr, y = factor(ytr, levels = sort(unique(ytr))), kernel = "linear", cost = 1,
           scale = FALSE, type = "C-classification")
  as.integer(as.character(predict(m, matrix(te, nrow = 1))))
}
models <- list(
  KNN_distance_w  = function(tr, ytr, te) knn_predict(tr, ytr, te, 3, TRUE),
  KNN_k1          = function(tr, ytr, te) knn_predict(tr, ytr, te, 1),
  KNN_k3          = function(tr, ytr, te) knn_predict(tr, ytr, te, 3),
  KNN_k5          = function(tr, ytr, te) knn_predict(tr, ytr, te, 5),
  NearestCentroid = centroid_predict,
  GaussianNB      = gnb_predict,
  SVC_linear      = svc_predict)

mcc_multi <- function(t, p) {                    # Gorodkin (2004) K-category MCC
  C <- table(factor(t, levels = 1:K), factor(p, levels = 1:K))
  tk <- rowSums(C); pk <- colSums(C); c_ <- sum(diag(C)); s <- sum(C)
  den <- sqrt(s^2 - sum(pk^2)) * sqrt(s^2 - sum(tk^2))
  if (den == 0) 0 else (c_ * s - sum(tk * pk)) / den
}
score <- function(t, p) {
  rec <- sapply(1:K, function(c) mean(p[t == c] == c))
  prec <- sapply(1:K, function(c) if (any(p == c)) mean(t[p == c] == c) else 0)
  f1 <- ifelse(prec + rec > 0, 2 * prec * rec / (prec + rec), 0)
  po <- mean(t == p); pe <- sum(tabulate(t, K) * tabulate(p, K)) / length(t)^2
  c(Accuracy = po, Balanced_Accuracy = mean(rec), F1_Macro = mean(f1),
    MCC = mcc_multi(t, p), Cohen_Kappa = (po - pe) / (1 - pe))
}
loocv <- function(XX) {
  preds <- sapply(names(models), function(m) integer(n))
  for (i in 1:n) {
    f <- fold_pca(XX[-i, , drop = FALSE], XX[i, , drop = FALSE])
    for (m in names(models)) preds[i, m] <- models[[m]](f$tr, yi[-i], f$te)
  }
  t(sapply(names(models), function(m) score(yi, preds[, m])))
}

cat("\nLOOCV (real descriptors)...\n")
res_real <- loocv(X); print(round(res_real, 4))
write.csv(res_real, file.path(out_dir, "R_loocv_real.csv"))

null_csv <- file.path(py_dir, "null_seed42_matrix.csv")
if (file.exists(null_csv)) {
  nm <- read.csv(null_csv, check.names = FALSE)
  stopifnot(identical(nm$Amino_Acid, df$Amino_Acid))
  Xn <- as.matrix(nm[, desc_cols])
  cat("\nLOOCV (seed-42 null control, matrix exported by Python)...\n")
  res_null <- loocv(Xn); print(round(res_null, 4))
  write.csv(res_null, file.path(out_dir, "R_loocv_null.csv"))
}

# -----------------------------------------------------------------------------
# 11. Cross-language comparison with the Python results (if available)
# -----------------------------------------------------------------------------
compare <- function(py_file, r_res, label) {
  if (!file.exists(py_file)) return(invisible(NULL))
  py <- read.csv(py_file, row.names = 1, check.names = FALSE)
  cols <- colnames(r_res); rows <- intersect(rownames(r_res), rownames(py))
  d <- abs(as.matrix(py[rows, cols]) - r_res[rows, cols])
  cat(sprintf("\nMax |Python - R| difference (%s): %.2e\n", label, max(d, na.rm = TRUE)))
  print(round(d, 6))
}
compare(file.path(py_dir, "results_real.csv"), res_real, "real")
if (exists("res_null")) compare(file.path(py_dir, "results_null.csv"), res_null, "null")

writeLines(capture.output(sessionInfo()), file.path(out_dir, "R_sessionInfo.txt"))
cat("\nR workflow complete. Outputs in", normalizePath(out_dir), "\n")
