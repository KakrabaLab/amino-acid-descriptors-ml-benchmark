# Amino acid descriptor ML benchmark: reproducible workflow (v4)

This workflow reproduces every number, table and figure in *"Machine Learning and Statistical Benchmarking of 39 Classifiers for the Physicochemical Classification of the 20 Standard Amino Acids from a Unified Molecular Descriptor Set, with Explicit Null-Control Validation."*

```
bash run_all.sh merged_molecular_descriptors_columns_renamed.csv
```

| Step | Script | Produces | Runtime (2 cores) |
|---|---|---|---|
| 1 | `python/amino_acid_pipeline_v4.py` | 39 × 17 LOOCV metrics for the real data and the seed-42 null (Tables 6–7, S1–S2), out-of-fold predictions, null matrix for R | ~2 min |
| 2 | `python/amino_acid_pipeline_v4.py --null-seeds 0-99` | 100-seed null-control replicate (Section 3.2, Figure 6) | ~40 min |
| 3 | `python/amino_acid_unsupervised_v4.py` | Tables 1–5, permutation test, consensus matrix, Kruskal–Wallis/BH, PCA/t-SNE/MDS, RF importance | ~30 s |
| 4 | `python/make_figures_v4.py` | Figures 1–12 as PNG (300 dpi), TIFF (600 dpi, LZW) and PDF | ~1 min |
| 5 | `R/amino_acid_workflow.R` | Parallel R implementation plus a cross-check against the Python results | ~1 min |

Environment for the rerun: Python 3.13, scikit-learn 1.9.1, NumPy 2.5.3, SciPy 1.18.1, pandas 3.0.5, matplotlib 3.11.2. R needs the CRAN packages `cluster` and `e1071`.

## Reproducibility audit (rerun on 2026-10-28)

**Reproduced exactly:**
- the v3 supervised pipeline, bit for bit, for every technique that fits in all 20 folds
- Tables 1, 2, 4 and 5
- PCA variance (34.6%, 14.6%; 12 components reach 90%)
- k-means and DBSCAN values in Table 3
- the permutation test (ARI 0.243; null mean −0.0022; 95th percentile 0.0944; p = 0.0005)
- the Kruskal–Wallis screen (2,499 nominal; 0 after FDR; minimum q 0.0964)
- the confusion matrix and ROC for the best model (macro AUC 0.7818)
- consensus clustering (0.7011; aromatic 0.9471 ± 0.0748)

**Errors found and corrected in the manuscript (tracked):**

| Issue | Before | After rerun |
|---|---|---|
| LinearSVC and NuSVC fail in the 2 folds holding out Asp/Glu; v3 silently dropped those folds (BA averaged over 4 classes) | NuSVC real BA 0.595 (rank 3); LinearSVC 0.531; best null 0.3786 (LinearSVC) | Failed folds scored as errors: NuSVC 0.476 (rank 11); LinearSVC 0.425; best null 0.3571 (4 linear models tied) |
| Bank-wide summary | mean BA 0.3998 vs 0.2072; 33/39 vs 12/39 above chance | 0.3928 vs 0.2039 over the 38 evaluable techniques; 32/38 vs 11/38 (QDA fails in every fold and is not estimable) |
| Table 6, LDA_shrinkage AUC | 0.722 | 0.711 (the supplied v3 script also gives 0.711) |
| Columns removed by the zero-variance filter | 9,426 in Methods vs 9,427 in Abstract | 9,427 (16,382 − 9,427 = 6,955, which matches the data) |
| Silhouette in Table 2 vs Table 3 | 0.308 vs 0.226 for the same solution, metric not stated | Manhattan (Table 2) vs Euclidean (Table 3); now stated; GMM and spectral rows added |
| Multi-seed null placeholders | [mean ± SD], [x], … | 100 seeds: bank mean 0.1747 ± 0.0225; kNN beats all 100 (p = 0.0099); 31/32 beat their null 95th percentile |
| Consensus values read from colour scale | ≈0.7–0.85, ≈0.75, ≈0.5 | exact: 0.68–0.83, 0.80 (0.74–0.88), 0.47 |
| Figure 9 / Section 3.6 descriptor names | named 3D-MoRSE etc.; single RF | Not reproducible: the file has anonymised names and single-seed Gini importance is unstable (10/20 overlap). Now averaged over 10 seeds, with labels by column id, block and statistic |
| Citations | [15] for the graph-theoretic study | [16] |
| Limitation (4) | "a standard, , but" | "a standard textbook scheme [62], but" |

**Settings recovered by trial** (not stated in the original; please confirm against `make_figures_v3.py`):
- GMM: diagonal covariance, `n_init = 10`, `random_state = 42`
- spectral clustering: nearest-neighbour affinity
- consensus clustering: re-standardised within each subsample

**Still open, needs the authors:**
- the version or commit of the descriptor-generation script, plus its RDKit and Python versions
- retained conformers per amino acid (the analysis table shows that only glycine kept a single conformer)
- verifying the 16,382-column source total
- the d1–d6977 → descriptor-name dictionary

## R workflow status

The R script could not be executed in the environment used for the rerun (no R installation and no CRAN access). Its algorithms were ported line by line to NumPy, and the port reproduces the scikit-learn results exactly (all differences 0): external indices, CH/DB, distance-weighted kNN, kNN k = 1/3/5, nearest centroid, Gaussian NB and linear SVC, on both the real and the null data. Run it once locally. Its last section prints the maximum |Python − R| difference per technique. Permutation and consensus results use R's RNG, so they will match the Python values in magnitude but not to the digit.
