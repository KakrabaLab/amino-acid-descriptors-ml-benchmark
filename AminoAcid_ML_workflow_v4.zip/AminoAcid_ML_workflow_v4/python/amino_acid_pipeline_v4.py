"""
amino_acid_pipeline_v4.py -- Supervised LOOCV benchmark (39 techniques x 17 metrics)
on the unified 6,977-column amino acid molecular descriptor table, with a seed-42
synthetic null control and a multi-seed (default 100 seeds) null-control replicate.

Changes relative to v3 (reproducibility audit, 2026-10-28)
----------------------------------------------------------
1. FAILED FOLDS ARE NOW COUNTED AS ERRORS. In v3, a fold in which a classifier
   could not be fitted was silently dropped, and metrics were computed on the
   remaining folds only. Under LOOCV this happens for LinearSVC (its internal
   2-fold Platt calibration needs >= 2 training members per class) and for
   NuSVC (nu = 0.3 becomes infeasible) whenever an acidic residue (Asp or Glu,
   class size 2) is held out. v3 therefore scored these two models on 18 of 20
   amino acids and computed balanced accuracy over 4 instead of 5 classes,
   which inflated their scores. v4 records a "no prediction" (-1) for each
   failed fold, scores it as a misclassification, and computes every
   label-based metric over all n = 20 amino acids and all 5 classes.
   Probability-based metrics (ROC-AUC, log loss, top-2 accuracy) are reported
   only when probabilities exist for all 20 folds.
2. Techniques that fail in EVERY fold (QDA: scikit-learn's QDA raises a
   rank-deficiency error because each class has fewer members than the 19 PCA
   components) are flagged "not estimable" and excluded from bank-wide
   summaries, which are therefore computed over the evaluable techniques.
3. Multi-seed null control (--null-seeds), out-of-fold predictions/probabilities
   saved for figure generation, and a run manifest with software versions.

The model zoo, hyper-parameters, preprocessing (StandardScaler -> PCA(19) inside
each training fold) and seeds are IDENTICAL to v3, so all fully-valid models give
bit-identical results to v3.

Usage
-----
  python amino_acid_pipeline_v4.py --input merged.csv --outdir results
  python amino_acid_pipeline_v4.py --input merged.csv --outdir results \
         --null-seeds 0-99 --n-jobs 2        # multi-seed null replicate
"""
import argparse
import json
import platform
import sys
import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

RANDOM_STATE = 42
CHANCE = 0.20
NO_PRED = -1

CLASS_MAP = {
    "Glycine": "Nonpolar_Aliphatic", "Alanine": "Nonpolar_Aliphatic",
    "Valine": "Nonpolar_Aliphatic", "Leucine": "Nonpolar_Aliphatic",
    "Isoleucine": "Nonpolar_Aliphatic", "Methionine": "Nonpolar_Aliphatic",
    "Proline": "Nonpolar_Aliphatic",
    "Phenylalanine": "Aromatic", "Tyrosine": "Aromatic", "Tryptophan": "Aromatic",
    "Serine": "Polar_Uncharged", "Threonine": "Polar_Uncharged",
    "Cysteine": "Polar_Uncharged", "Asparagine": "Polar_Uncharged",
    "Glutamine": "Polar_Uncharged",
    "Lysine": "Positively_Charged", "Arginine": "Positively_Charged",
    "Histidine": "Positively_Charged",
    "Aspartic Acid": "Negatively_Charged", "Glutamic Acid": "Negatively_Charged",
}
ONE_LETTER = {
    "Alanine": "A", "Arginine": "R", "Asparagine": "N", "Aspartic Acid": "D",
    "Cysteine": "C", "Glutamic Acid": "E", "Glutamine": "Q", "Glycine": "G",
    "Histidine": "H", "Isoleucine": "I", "Leucine": "L", "Lysine": "K",
    "Methionine": "M", "Phenylalanine": "F", "Proline": "P", "Serine": "S",
    "Threonine": "T", "Tryptophan": "W", "Tyrosine": "Y", "Valine": "V",
}
ID_COL = "Amino_Acid"
NON_DESCRIPTOR_COLS = {"Amino_Acid", "Symbol"}

METRIC_NAMES = ["Accuracy", "Balanced_Accuracy", "Precision_Macro", "Precision_Weighted",
                "Recall_Macro", "Recall_Weighted", "F1_Macro", "F1_Weighted", "F1_Micro",
                "MCC", "Cohen_Kappa", "Jaccard_Macro", "Hamming_Loss", "Zero_One_Loss",
                "ROC_AUC_Macro_OVR", "Log_Loss", "Top2_Accuracy"]


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------
def load_and_prepare(csv_path):
    df = pd.read_csv(csv_path)
    descriptor_cols = [c for c in df.columns if c not in NON_DESCRIPTOR_COLS]
    df["Class"] = df[ID_COL].map(CLASS_MAP)
    assert df["Class"].notna().all(), "Unmapped amino acids"
    classes_sorted = sorted(df["Class"].unique())
    y = pd.Categorical(df["Class"], categories=classes_sorted).codes.astype(int)
    X = df[descriptor_cols].apply(pd.to_numeric, errors="coerce").to_numpy(float)
    assert not np.isnan(X).any(), "Unexpected NaNs in descriptor block."
    n_const = int((X.std(axis=0) == 0).sum())
    return df, X, y, classes_sorted, descriptor_cols, n_const


def make_null(shape, seed):
    """Synthetic null control: iid N(0,1), numpy RandomState(seed)."""
    return np.random.RandomState(seed).normal(0.0, 1.0, size=shape)


# ---------------------------------------------------------------------------
# Model zoo (identical to v3)
# ---------------------------------------------------------------------------
def make_models():
    from sklearn.linear_model import (LogisticRegression, RidgeClassifier, SGDClassifier,
                                      Perceptron, PassiveAggressiveClassifier)
    from sklearn.svm import SVC, LinearSVC, NuSVC
    from sklearn.neighbors import KNeighborsClassifier, NearestCentroid
    from sklearn.naive_bayes import GaussianNB, BernoulliNB
    from sklearn.tree import DecisionTreeClassifier, ExtraTreeClassifier
    from sklearn.ensemble import (RandomForestClassifier, ExtraTreesClassifier,
                                  GradientBoostingClassifier, AdaBoostClassifier,
                                  BaggingClassifier, HistGradientBoostingClassifier)
    from sklearn.neural_network import MLPClassifier
    from sklearn.discriminant_analysis import (LinearDiscriminantAnalysis,
                                               QuadraticDiscriminantAnalysis)
    from sklearn.gaussian_process import GaussianProcessClassifier
    from sklearn.gaussian_process.kernels import RBF
    from sklearn.dummy import DummyClassifier
    from sklearn.calibration import CalibratedClassifierCV
    R = RANDOM_STATE
    return {
        "Dummy_MostFrequent": DummyClassifier(strategy="most_frequent"),
        "Dummy_Stratified": DummyClassifier(strategy="stratified", random_state=R),
        "Dummy_Uniform": DummyClassifier(strategy="uniform", random_state=R),
        "LogisticRegression": LogisticRegression(max_iter=5000, random_state=R),
        "LogisticRegression_L1": LogisticRegression(max_iter=5000, penalty="l1", solver="saga", random_state=R),
        "RidgeClassifier": RidgeClassifier(random_state=R),
        "SGDClassifier_log": SGDClassifier(loss="log_loss", max_iter=2000, random_state=R),
        "SGDClassifier_hinge": SGDClassifier(loss="hinge", max_iter=2000, random_state=R),
        "Perceptron": Perceptron(max_iter=2000, random_state=R),
        "PassiveAggressive": PassiveAggressiveClassifier(max_iter=2000, random_state=R),
        "LinearSVC": CalibratedClassifierCV(LinearSVC(max_iter=5000, random_state=R), cv=2),
        "SVC_linear": SVC(kernel="linear", probability=True, random_state=R),
        "SVC_rbf": SVC(kernel="rbf", probability=True, random_state=R),
        "SVC_poly": SVC(kernel="poly", degree=3, probability=True, random_state=R),
        "SVC_sigmoid": SVC(kernel="sigmoid", probability=True, random_state=R),
        "NuSVC": NuSVC(nu=0.3, probability=True, random_state=R),
        "KNN_k1": KNeighborsClassifier(n_neighbors=1),
        "KNN_k3": KNeighborsClassifier(n_neighbors=3),
        "KNN_k5": KNeighborsClassifier(n_neighbors=5),
        "KNN_distance_w": KNeighborsClassifier(n_neighbors=3, weights="distance"),
        "NearestCentroid": NearestCentroid(),
        "GaussianNB": GaussianNB(),
        "BernoulliNB": BernoulliNB(),
        "DecisionTree": DecisionTreeClassifier(random_state=R),
        "ExtraTree": ExtraTreeClassifier(random_state=R),
        "RandomForest_100": RandomForestClassifier(n_estimators=100, random_state=R),
        "RandomForest_500": RandomForestClassifier(n_estimators=500, random_state=R),
        "ExtraTrees": ExtraTreesClassifier(n_estimators=300, random_state=R),
        "GradientBoosting": GradientBoostingClassifier(random_state=R),
        "HistGradientBoosting": HistGradientBoostingClassifier(random_state=R),
        "AdaBoost": AdaBoostClassifier(random_state=R),
        "Bagging_Tree": BaggingClassifier(random_state=R),
        "Bagging_KNN": BaggingClassifier(estimator=KNeighborsClassifier(), random_state=R),
        "LDA": LinearDiscriminantAnalysis(),
        "LDA_shrinkage": LinearDiscriminantAnalysis(solver="lsqr", shrinkage="auto"),
        "QDA": QuadraticDiscriminantAnalysis(reg_param=0.5),
        "GaussianProcess": GaussianProcessClassifier(kernel=1.0 * RBF(1.0), random_state=R),
        "MLP_small": MLPClassifier(hidden_layer_sizes=(16,), max_iter=3000, random_state=R),
        "MLP_deep": MLPClassifier(hidden_layer_sizes=(32, 16), max_iter=3000, random_state=R),
    }


# ---------------------------------------------------------------------------
# LOOCV for one technique
# ---------------------------------------------------------------------------
def loocv_one(name, X, y, n_classes, n_pca):
    from sklearn.preprocessing import StandardScaler
    from sklearn.decomposition import PCA
    from sklearn.pipeline import Pipeline
    from sklearn.model_selection import LeaveOneOut

    n = len(y)
    pred = np.full(n, NO_PRED, dtype=int)
    proba = np.full((n, n_classes), np.nan)
    fit_times, fail_idx = [], []
    for tr, te in LeaveOneOut().split(X):
        pipe = Pipeline([("scaler", StandardScaler()),
                         ("pca", PCA(n_components=n_pca, random_state=RANDOM_STATE)),
                         ("clf", make_models()[name])])
        t0 = time.time()
        try:
            pipe.fit(X[tr], y[tr])
        except Exception:
            fail_idx.append(int(te[0]))
            continue
        fit_times.append(time.time() - t0)
        pred[te] = pipe.predict(X[te])
        if hasattr(pipe, "predict_proba"):
            try:
                p = pipe.predict_proba(X[te])
                for j, c in enumerate(pipe.named_steps["clf"].classes_):
                    proba[te, int(c)] = p[:, j]
                # classes absent from the training fold get probability 0
                proba[te] = np.nan_to_num(proba[te], nan=0.0)
            except Exception:
                pass
    return pred, proba, fit_times, fail_idx


def compute_metrics(y, pred, proba, n_classes):
    from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                                 matthews_corrcoef, cohen_kappa_score, jaccard_score,
                                 hamming_loss, zero_one_loss, roc_auc_score, log_loss,
                                 top_k_accuracy_score)
    labels = list(range(n_classes))
    m = {
        "Accuracy": accuracy_score(y, pred),
        # balanced accuracy = macro recall over the 5 TRUE classes; a failed fold
        # (pred = -1) is a miss for its true class
        "Balanced_Accuracy": recall_score(y, pred, labels=labels, average="macro", zero_division=0),
        "Precision_Macro": precision_score(y, pred, labels=labels, average="macro", zero_division=0),
        "Precision_Weighted": precision_score(y, pred, labels=labels, average="weighted", zero_division=0),
        "Recall_Macro": recall_score(y, pred, labels=labels, average="macro", zero_division=0),
        "Recall_Weighted": recall_score(y, pred, labels=labels, average="weighted", zero_division=0),
        "F1_Macro": f1_score(y, pred, labels=labels, average="macro", zero_division=0),
        "F1_Weighted": f1_score(y, pred, labels=labels, average="weighted", zero_division=0),
        "F1_Micro": f1_score(y, pred, labels=labels, average="micro", zero_division=0),
        "MCC": matthews_corrcoef(y, pred),
        "Cohen_Kappa": cohen_kappa_score(y, pred),
        "Jaccard_Macro": jaccard_score(y, pred, labels=labels, average="macro", zero_division=0),
        "Hamming_Loss": hamming_loss(y, pred),
        "Zero_One_Loss": zero_one_loss(y, pred),
        "ROC_AUC_Macro_OVR": np.nan, "Log_Loss": np.nan, "Top2_Accuracy": np.nan,
    }
    if not np.isnan(proba).any():
        P = proba / proba.sum(axis=1, keepdims=True)
        m["ROC_AUC_Macro_OVR"] = roc_auc_score(y, P, multi_class="ovr", average="macro", labels=labels)
        m["Log_Loss"] = log_loss(y, P, labels=labels)
        m["Top2_Accuracy"] = top_k_accuracy_score(y, P, k=2, labels=labels)
    return m


def run_benchmark(X, y, n_classes, n_pca, keep_oof=True):
    rows, oof = {}, {}
    for name in make_models():
        pred, proba, ft, fails = loocv_one(name, X, y, n_classes, n_pca)
        n_valid = len(y) - len(fails)
        if n_valid == 0:
            m = {k: np.nan for k in METRIC_NAMES}
            status = "not estimable (failed in all folds)"
        else:
            m = compute_metrics(y, pred, proba, n_classes)
            status = "complete" if not fails else f"partial ({len(fails)} failed folds scored as errors)"
        m["Mean_Fit_Time_ms"] = np.mean(ft) * 1000 if ft else np.nan
        m["N_Valid_Folds"] = n_valid
        m["Status"] = status
        rows[name] = m
        if keep_oof:
            oof[name] = {"pred": pred, "proba": proba, "failed": fails}
    return pd.DataFrame(rows).T, oof


def bank_summary(res, label):
    ok = res[res["N_Valid_Folds"] > 0]
    ba = ok["Balanced_Accuracy"].astype(float)
    return {"feature_set": label, "n_evaluable": int(len(ok)), "n_total": int(len(res)),
            "mean_balanced_accuracy": float(ba.mean()), "sd_balanced_accuracy": float(ba.std()),
            "n_above_chance": int((ba > CHANCE + 1e-12).sum())}


def _null_seed_job(seed, shape, y, n_classes, n_pca):
    Xn = make_null(shape, seed)
    res, _ = run_benchmark(Xn, y, n_classes, n_pca, keep_oof=False)
    out = res[["Balanced_Accuracy", "Accuracy", "N_Valid_Folds"]].copy()
    out["seed"] = seed
    return out.reset_index().rename(columns={"index": "Model"})


def parse_seeds(s):
    if "-" in s:
        a, b = s.split("-")
        return list(range(int(a), int(b) + 1))
    return [int(v) for v in s.split(",")]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--outdir", default="./results_v4")
    ap.add_argument("--null-seeds", default=None, help="e.g. 0-99 (runs ONLY the multi-seed null)")
    ap.add_argument("--n-jobs", type=int, default=1)
    a = ap.parse_args()
    out = Path(a.outdir); out.mkdir(parents=True, exist_ok=True)

    df, X, y, classes, cols, n_const = load_and_prepare(a.input)
    n, p = X.shape; K = len(classes); n_pca = n - 1
    print(f"n = {n} amino acids, p = {p} descriptor columns, constant columns = {n_const}")

    if a.null_seeds:
        from joblib import Parallel, delayed
        seeds = parse_seeds(a.null_seeds)
        t0 = time.time()
        parts = Parallel(n_jobs=a.n_jobs, verbose=5)(
            delayed(_null_seed_job)(s, X.shape, y, K, n_pca) for s in seeds)
        long = pd.concat(parts, ignore_index=True)
        long.to_csv(out / "multiseed_null_long.csv", index=False)
        print(f"Multi-seed null finished: {len(seeds)} seeds in {time.time()-t0:.0f}s")
        return

    import sklearn, scipy
    manifest = {"python": sys.version.split()[0], "platform": platform.platform(),
                "numpy": np.__version__, "pandas": pd.__version__,
                "scikit_learn": sklearn.__version__, "scipy": scipy.__version__,
                "n": n, "p": p, "n_constant_columns": n_const, "n_pca": n_pca,
                "classes": classes, "class_counts": np.bincount(y).tolist(),
                "random_state": RANDOM_STATE}
    json.dump(manifest, open(out / "run_manifest.json", "w"), indent=2)

    Xnull = make_null(X.shape, RANDOM_STATE)
    pd.DataFrame(Xnull, columns=cols).assign(Amino_Acid=df[ID_COL]).to_csv(out / "null_seed42_matrix.csv", index=False)

    allres, alloof, summ = {}, {}, []
    for label, XX in [("real", X), ("null", Xnull)]:
        print(f"LOOCV benchmark: {label} ...")
        res, oof = run_benchmark(XX, y, K, n_pca)
        res.to_csv(out / f"results_{label}.csv")
        np.savez_compressed(out / f"oof_{label}.npz",
                            **{f"{k}__pred": v["pred"] for k, v in oof.items()},
                            **{f"{k}__proba": v["proba"] for k, v in oof.items()})
        summ.append(bank_summary(res, label))
        allres[label] = res
    pd.DataFrame(summ).to_csv(out / "bank_summary.csv", index=False)
    print(pd.DataFrame(summ))
    for label in allres:
        print(f"\nTop 12 ({label}) by balanced accuracy:")
        print(allres[label][["Accuracy", "Balanced_Accuracy", "F1_Macro", "MCC", "N_Valid_Folds"]]
              .sort_values("Balanced_Accuracy", ascending=False).head(12))


if __name__ == "__main__":
    main()
