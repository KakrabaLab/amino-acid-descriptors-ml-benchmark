"""
amino_acid_unsupervised_v4.py -- Unsupervised cross-check, external validation,
stability, significance testing, univariate screen, descriptor-block ablation and
descriptive projections for the unified amino acid descriptor table.

All settings below were recovered during the 2026-10-28 reproducibility audit as
the ones that reproduce the values reported in the manuscript, and are now fixed
explicitly so the analysis is deterministic.

Usage:  python amino_acid_unsupervised_v4.py --input merged.csv --outdir results
"""
import argparse
import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.cluster.hierarchy import linkage, cophenet, fcluster
from scipy.spatial.distance import pdist, squareform
from scipy.stats import kruskal, false_discovery_control
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans, SpectralClustering, DBSCAN
from sklearn.mixture import GaussianMixture
from sklearn.manifold import TSNE, MDS
from sklearn.ensemble import RandomForestClassifier
from sklearn import metrics as M

from amino_acid_pipeline_v4 import load_and_prepare, ONE_LETTER, RANDOM_STATE

GRAPH_COLS = slice(0, 22)          # d1-d22: graph-theoretic block
PHYS_COLS = slice(22, None)        # d23-d6977: 1D-4D cheminformatics block

# Column ranges of each descriptor family in the merged file. The merged file
# carries anonymised column names (d1..d6977), so these ranges were INFERRED
# from column order and exact structural identities (see infer_blocks()).
def infer_blocks(X):
    p = X.shape[1]
    binary = np.array([set(np.unique(X[:, j])) <= {0.0, 1.0} for j in range(p)])
    # 4D groups: mean, std, min, max, RANGE(=max-min), median, q25, q75, IQR(=q75-q25)
    first4d = None
    for s in range(22, p - 8):
        if (np.allclose(X[:, s + 4], X[:, s + 3] - X[:, s + 2]) and
                np.allclose(X[:, s + 8], X[:, s + 7] - X[:, s + 6]) and X[:, s + 4].std() > 0):
            first4d = s
            break
    fp = np.where(binary[22:first4d])[0] + 22
    # longest contiguous binary run = 2D fingerprint block
    runs, start = [], fp[0]
    for a, b in zip(fp[:-1], fp[1:]):
        if b != a + 1:
            runs.append((start, a)); start = b
    runs.append((start, fp[-1]))
    fp_start, fp_end = max(runs, key=lambda r: r[1] - r[0])
    # RDKit 2D scalar block starts 6 columns before its MolWt column; MolWt is the
    # first later column identical to the 1D molecular weight (d24)
    molwt_dups = [j for j in range(25, fp_start) if np.allclose(X[:, j], X[:, 23])]
    start2d = molwt_dups[-1] - 6 if molwt_dups else None
    blocks = {"Graph": (0, 21), "1D": (22, start2d - 1), "2D": (start2d, fp_end),
              "2D-FP": (fp_start, fp_end), "3D": (fp_end + 1, first4d - 1), "4D": (first4d, p - 1)}
    return blocks


def block_of(j, b):
    if j <= b["Graph"][1]: return "Graph"
    if j <= b["1D"][1]: return "1D"
    if b["2D-FP"][0] <= j <= b["2D-FP"][1]: return "2D-FP"
    if j <= b["2D"][1]: return "2D"
    if j <= b["3D"][1]: return "3D"
    return "4D"


STATS4D = ["Mean", "StdDev", "Min", "Max", "Range", "Median", "Q25", "Q75", "IQR"]


def stat4d(X, j, b):
    """Return the ensemble statistic of a 4D column when its 9-column group is intact."""
    for off in range(9):
        s = j - off
        if s < b["4D"][0] or s + 8 >= X.shape[1]:
            continue
        if (np.allclose(X[:, s + 4], X[:, s + 3] - X[:, s + 2]) and
                np.allclose(X[:, s + 8], X[:, s + 7] - X[:, s + 6])):
            return STATS4D[off]
    return ""


def ext(y, lab):
    return {"ARI": M.adjusted_rand_score(y, lab), "NMI": M.normalized_mutual_info_score(y, lab),
            "AMI": M.adjusted_mutual_info_score(y, lab), "V_measure": M.v_measure_score(y, lab),
            "Homogeneity": M.homogeneity_score(y, lab), "Completeness": M.completeness_score(y, lab),
            "Fowlkes_Mallows": M.fowlkes_mallows_score(y, lab)}


def internal(Z, lab, metric="cityblock"):
    return {"Silhouette": M.silhouette_score(Z, lab, metric=metric),
            "Silhouette_Euclidean": M.silhouette_score(Z, lab, metric="euclidean"),
            "Calinski_Harabasz": M.calinski_harabasz_score(Z, lab),
            "Davies_Bouldin": M.davies_bouldin_score(Z, lab)}


def hc_labels(Z, k, method="average", metric="cityblock"):
    L = linkage(pdist(Z, metric), method) if method != "ward" else linkage(Z, "ward")
    return fcluster(L, k, "maxclust"), L


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--outdir", default="./results_v4")
    a = ap.parse_args()
    out = Path(a.outdir); out.mkdir(parents=True, exist_ok=True)
    df, X, y, classes, cols, _ = load_and_prepare(a.input)
    names = df["Amino_Acid"].tolist()
    letters = [ONE_LETTER[s] for s in names]
    R = {}

    Z = StandardScaler().fit_transform(X)

    # ---- Table 1: cophenetic correlation --------------------------------
    configs = [("ward", "euclidean"), ("average", "cityblock"), ("average", "euclidean"),
               ("complete", "cityblock"), ("single", "cityblock")]
    t1 = []
    for meth, met in configs:
        D = pdist(Z, met)
        L = linkage(Z, "ward") if meth == "ward" else linkage(D, meth)
        t1.append({"method": meth, "metric": met, "cophenetic": cophenet(L, D)[0]})
    pd.DataFrame(t1).to_csv(out / "table1_cophenetic.csv", index=False)

    # ---- Table 2: internal indices k=2..5 -------------------------------
    t2 = []
    for k in range(2, 6):
        lab, L = hc_labels(Z, k)
        t2.append({"k": k, **internal(Z, lab), "ARI": M.adjusted_rand_score(y, lab)})
    pd.DataFrame(t2).to_csv(out / "table2_internal_k.csv", index=False)
    hc2, Lhc = hc_labels(Z, 2)
    hc5, _ = hc_labels(Z, 5)
    R["hc2_members"] = {letters[i]: int(hc2[i]) for i in range(20)}
    R["dendrogram_leaf_order"] = [letters[i] for i in
                                 __import__("scipy.cluster.hierarchy", fromlist=["leaves_list"]).leaves_list(Lhc)]

    # ---- Table 3/4: algorithm comparison ---------------------------------
    P19 = PCA(n_components=19, random_state=RANDOM_STATE).fit_transform(Z)
    algs = {
        "Hierarchical (k=2)": hc2,
        "Hierarchical (k=5)": hc5,
        "K-Means (k=2, PCA-19)": KMeans(2, random_state=RANDOM_STATE, n_init=10).fit_predict(P19),
        "GMM-diag (k=2, PCA-19)": GaussianMixture(2, covariance_type="diag", n_init=10,
                                                  random_state=RANDOM_STATE).fit(P19).predict(P19),
        "Spectral (k=2, PCA-19)": SpectralClustering(2, affinity="nearest_neighbors", n_neighbors=10,
                                                     random_state=RANDOM_STATE).fit_predict(P19),
    }
    t3, t4 = [], []
    for nm, lab in algs.items():
        t4.append({"algorithm": nm, **ext(y, lab)})
        if "k=5" not in nm:
            t3.append({"algorithm": nm, "n_clustered": 20, **internal(Z, lab)})
    dbgrid = []
    for eps in np.arange(20, 161, 4):
        lab = DBSCAN(eps=float(eps), min_samples=2).fit_predict(Z)
        m = lab != -1
        nclu = len(set(lab[m]))
        row = {"eps": float(eps), "n_noise": int((~m).sum()), "n_clusters": nclu}
        if nclu >= 2:
            row.update(internal(Z[m], lab[m]))
        dbgrid.append(row)
    dbgrid = pd.DataFrame(dbgrid)
    dbgrid.to_csv(out / "dbscan_grid.csv", index=False)
    ok = dbgrid.dropna(subset=["Silhouette_Euclidean"])
    best = ok.loc[ok["Silhouette_Euclidean"].idxmax()]
    lab = DBSCAN(eps=float(best.eps), min_samples=2).fit_predict(Z); m = lab != -1
    t3.append({"algorithm": f"DBSCAN (eps = {best.eps:g}, min_samples = 2)",
               "n_clustered": int(m.sum()), **internal(Z[m], lab[m])})
    pd.DataFrame(t3).to_csv(out / "table3_algorithms_internal.csv", index=False)
    pd.DataFrame(t4).to_csv(out / "table4_external.csv", index=False)

    # ---- Label permutation test (2,000) ---------------------------------
    rng = np.random.RandomState(RANDOM_STATE)
    obs = M.adjusted_rand_score(y, hc2)
    null = np.array([M.adjusted_rand_score(rng.permutation(y), hc2) for _ in range(2000)])
    R["perm"] = {"observed_ARI": obs, "null_mean": null.mean(), "null_p95": np.percentile(null, 95),
                 "p_value": (1 + (null >= obs).sum()) / (1 + len(null)), "n_perm": 2000}

    # ---- Bootstrap consensus (100 x 80%), re-standardised per subsample ----
    rng = np.random.RandomState(RANDOM_STATE)
    Mx = np.zeros((20, 20)); Cn = np.zeros((20, 20))
    for _ in range(100):
        idx = np.sort(rng.choice(20, 16, replace=False))
        Zs = StandardScaler().fit_transform(X[idx])
        lab = fcluster(linkage(pdist(Zs, "cityblock"), "average"), 2, "maxclust")
        same = (lab[:, None] == lab[None, :]).astype(float)
        Mx[np.ix_(idx, idx)] += same; Cn[np.ix_(idx, idx)] += 1
    K = Mx / np.maximum(Cn, 1)
    pd.DataFrame(K, index=letters, columns=letters).to_csv(out / "consensus_matrix.csv")
    iu = np.triu_indices(20, 1)
    L2I = {l: i for i, l in enumerate(letters)}
    def pairs(group):
        return [K[L2I[a_], L2I[b_]] for a_, b_ in itertools.combinations(group, 2)]
    big = [l for l in letters if l not in "FWYRKH"]
    aro = pairs("FWY")
    R["consensus"] = {
        "mean_all_pairs": K[iu].mean(),
        "aromatic_mean": np.mean(aro), "aromatic_sd": np.std(aro),
        "R_with_aromatic": [K[L2I["R"], L2I[x]] for x in "FWY"],
        "K_with_aromatic": [K[L2I["K"], L2I[x]] for x in "FWY"],
        "R_with_bigblock_mean": float(np.mean([K[L2I["R"], L2I[x]] for x in big])),
        "K_with_bigblock_mean": float(np.mean([K[L2I["K"], L2I[x]] for x in big])),
        "H_with_bigblock_mean": float(np.mean([K[L2I["H"], L2I[x]] for x in big])),
        "H_with_aromatic": [K[L2I["H"], L2I[x]] for x in "FWY"],
        "R_K": K[L2I["R"], L2I["K"]],
        "n_pairs_eq1": int((K[iu] == 1).sum()), "n_pairs_eq0": int((K[iu] == 0).sum()),
        "pairs_eq0": [f"{letters[i]}-{letters[j]}" for i, j in zip(*iu) if K[i, j] == 0],
    }

    # ---- Kruskal-Wallis + BH FDR -----------------------------------------
    pv = np.array([kruskal(*[X[y == c, j] for c in range(len(classes))]).pvalue for j in range(X.shape[1])])
    pv = np.nan_to_num(pv, nan=1.0)
    q = false_discovery_control(pv, method="bh")
    R["kruskal"] = {"n_nominal": int((pv < 0.05).sum()), "pct_nominal": float((pv < 0.05).mean() * 100),
                    "min_q": float(q.min()), "n_fdr": int((q < 0.05).sum()), "min_p": float(pv.min())}
    pd.DataFrame({"descriptor": cols, "p": pv, "q_BH": q}).to_csv(out / "kruskal_wallis.csv", index=False)

    # ---- Table 5: descriptor block ablation ------------------------------
    t5 = []
    for nm, sl in [("Graph theoretic only (d1-d22)", GRAPH_COLS),
                   ("Physicochemical only (d23-d6977)", PHYS_COLS),
                   ("Combined / unified", slice(None))]:
        Zb = StandardScaler().fit_transform(X[:, sl])
        D = pdist(Zb, "cityblock"); L = linkage(D, "average")
        t5.append({"block": nm, "n_features": Zb.shape[1], "cophenetic": cophenet(L, D)[0],
                   "ARI_k2": M.adjusted_rand_score(y, fcluster(L, 2, "maxclust")),
                   "ARI_k5": M.adjusted_rand_score(y, fcluster(L, 5, "maxclust"))})
    pd.DataFrame(t5).to_csv(out / "table5_ablation.csv", index=False)

    # ---- Descriptive PCA / t-SNE / MDS / RF importance ---------------------
    pca = PCA().fit(Z)
    sc = pca.transform(Z)[:, :2]
    evr = pca.explained_variance_ratio_
    R["pca"] = {"PC1": evr[0], "PC2": evr[1], "n_for_90": int(np.argmax(np.cumsum(evr) >= 0.90) + 1),
                "evr": evr[:19].tolist()}
    pd.DataFrame({"aa": letters, "PC1": sc[:, 0], "PC2": sc[:, 1]}).to_csv(out / "pca_scores.csv", index=False)
    ts = TSNE(n_components=2, perplexity=5, random_state=RANDOM_STATE, init="pca").fit_transform(Z)
    # classical (Torgerson) MDS on Euclidean distances
    Dm = squareform(pdist(Z)); n = len(Z); J = np.eye(n) - 1 / n
    B = -0.5 * J @ (Dm ** 2) @ J; w, V = np.linalg.eigh(B); o = np.argsort(w)[::-1]
    md = V[:, o[:2]] * np.sqrt(w[o[:2]])
    pd.DataFrame({"aa": letters, "tSNE1": ts[:, 0], "tSNE2": ts[:, 1],
                  "MDS1": md[:, 0], "MDS2": md[:, 1]}).to_csv(out / "embeddings.csv", index=False)

    blocks = infer_blocks(X)
    R["blocks_inferred_1based"] = {k: [v[0] + 1, v[1] + 1] for k, v in blocks.items()}
    # Random Forest Gini importance averaged over 10 seeds x 500 trees (stabilised)
    imps = np.array([RandomForestClassifier(n_estimators=500, random_state=s).fit(Z, y).feature_importances_
                     for s in range(10)])
    imp, imp_sd = imps.mean(0), imps.std(0)
    top = np.argsort(-imp)[:20]
    single = RandomForestClassifier(n_estimators=500, random_state=RANDOM_STATE).fit(Z, y).feature_importances_
    rank_single = set(np.argsort(-single)[:20])
    rows = [{"descriptor": cols[j], "block": block_of(j, blocks),
             "stat": stat4d(X, j, blocks) if block_of(j, blocks) == "4D" else "",
             "importance": imp[j], "sd_over_seeds": imp_sd[j], "in_seed42_top20": j in rank_single}
            for j in top]
    pd.DataFrame(rows).to_csv(out / "rf_importance_top20.csv", index=False)
    R["rf"] = {"top_importance": float(imp[top[0]]), "overlap_seed42_top20": int(sum(r["in_seed42_top20"] for r in rows)),
               "block_counts_top20": pd.Series([r["block"] for r in rows]).value_counts().to_dict()}

    json.dump(R, open(out / "unsupervised_summary.json", "w"), indent=2, default=float)
    print(json.dumps(R, indent=1, default=float)[:4000])


if __name__ == "__main__":
    main()
