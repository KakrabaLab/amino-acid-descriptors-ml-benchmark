"""
make_figures_v4.py -- Regenerates Figures 1-12 from the outputs of
amino_acid_pipeline_v4.py and amino_acid_unsupervised_v4.py.

Each figure is written as PNG (300 dpi, for the manuscript), TIFF (600 dpi, LZW)
and PDF (vector).

Usage: python make_figures_v4.py --input merged.csv --results results --figdir figures
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D
from scipy.cluster.hierarchy import linkage, dendrogram
from scipy.spatial.distance import pdist
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_curve, auc, confusion_matrix

from amino_acid_pipeline_v4 import load_and_prepare, ONE_LETTER

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False,
                     "axes.spines.right": False, "savefig.bbox": "tight"})

CLASS_COL = {"Aromatic": "#E07B39", "Negatively_Charged": "#8E6BB8", "Nonpolar_Aliphatic": "#3E6DB5",
             "Polar_Uncharged": "#3F9E4D", "Positively_Charged": "#C8403B"}
REAL_C, NULL_C = "#3E6DB5", "#C8403B"
STD_ORDER = list("ARNDCEQGHILKMFPSTWYV")


def pretty(c):
    return c.replace("_", " ").replace("Nonpolar Aliphatic", "Nonpolar/Aliphatic")


def save(fig, figdir, name):
    fig.savefig(figdir / f"{name}.png", dpi=300)
    fig.savefig(figdir / f"{name}.pdf")
    fig.savefig(figdir / f"{name}.tiff", dpi=600, pil_kwargs={"compression": "tiff_lzw"})
    plt.close(fig)


def class_legend(classes):
    return [Line2D([0], [0], marker="o", ls="", mfc=CLASS_COL[c], mec="k", ms=9, label=pretty(c))
            for c in classes]


def label_points(ax, x, y, labels, colors, size=210):
    ax.scatter(x, y, s=size, c=colors, edgecolors="k", linewidths=0.8, zorder=3)
    for xi, yi, l in zip(x, y, labels):
        ax.text(xi, yi, l, ha="center", va="center", fontsize=8, fontweight="bold", color="white", zorder=4)


def declutter(xy, min_dist, iters=200):
    """Nudge points apart (display only) so overlapping labels stay legible."""
    p = xy.astype(float).copy()
    for _ in range(iters):
        moved = False
        for i in range(len(p)):
            for j in range(i + 1, len(p)):
                d = p[i] - p[j]; r = np.hypot(*d)
                if r < min_dist:
                    v = d / r if r > 0 else np.array([1.0, 0.0])
                    p[i] += v * (min_dist - r) / 2; p[j] -= v * (min_dist - r) / 2; moved = True
        if not moved:
            break
    return p


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", required=True)
    ap.add_argument("--results", default="./results_v4")
    ap.add_argument("--figdir", default="./figures_v4")
    a = ap.parse_args()
    res, figdir = Path(a.results), Path(a.figdir); figdir.mkdir(parents=True, exist_ok=True)
    df, X, y, classes, cols, _ = load_and_prepare(a.input)
    letters = [ONE_LETTER[s] for s in df["Amino_Acid"]]
    cls = [classes[i] for i in y]
    colors = [CLASS_COL[c] for c in cls]
    S = json.load(open(res / "unsupervised_summary.json"))
    Z = StandardScaler().fit_transform(X)

    # ---------------- Figure 1: PCA scatter --------------------------------
    pc = pd.read_csv(res / "pca_scores.csv")
    xy = declutter(pc[["PC1", "PC2"]].to_numpy(), min_dist=6.5)
    fig, ax = plt.subplots(figsize=(7, 5))
    label_points(ax, xy[:, 0], xy[:, 1], letters, colors)
    ax.set_xlabel(f"PC1 ({S['pca']['PC1']*100:.1f}%)"); ax.set_ylabel(f"PC2 ({S['pca']['PC2']*100:.1f}%)")
    ax.axhline(0, c="0.85", lw=0.8, zorder=0); ax.axvline(0, c="0.85", lw=0.8, zorder=0)
    ax.legend(handles=class_legend(classes), loc="lower left", frameon=True, fontsize=9)
    save(fig, figdir, "Figure1_PCA")

    # ---------------- Figure 2: variance explained --------------------------
    evr = np.array(S["pca"]["evr"]) * 100; k = np.arange(1, len(evr) + 1)
    fig, ax = plt.subplots(figsize=(7, 4.6))
    ax.bar(k, evr, color="#8FA8D4", label="Per-component variance")
    ax2 = ax.twinx(); ax2.spines["right"].set_visible(True)
    ax2.plot(k, np.cumsum(evr), "-o", c="#E07B39", ms=4, label="Cumulative variance")
    ax2.axhline(90, ls="--", c="0.5", lw=1); ax2.set_ylim(30, 102)
    ax.set_xticks(k); ax.set_xlabel("Principal component (descriptive fit to all 20 amino acids)")
    ax.set_ylabel("Variance explained (%)"); ax2.set_ylabel("Cumulative variance (%)")
    h1, l1 = ax.get_legend_handles_labels(); h2, l2 = ax2.get_legend_handles_labels()
    ax.legend(h1 + h2, l1 + l2, loc="center right")
    save(fig, figdir, "Figure2_PCA_variance")

    # ---------------- Figure 3: dendrogram + class bar + heatmap -------------
    L = linkage(pdist(Z, "cityblock"), "average")
    fig = plt.figure(figsize=(10, 7.6))
    axd = fig.add_axes([0.02, 0.08, 0.15, 0.80]); axc = fig.add_axes([0.175, 0.08, 0.02, 0.80])
    axh = fig.add_axes([0.20, 0.08, 0.55, 0.80]); axcb = fig.add_axes([0.20, 0.91, 0.20, 0.022])
    dn = dendrogram(L, orientation="left", no_labels=True, ax=axd, color_threshold=0, above_threshold_color="0.35")
    order = dn["leaves"]          # leaf i is drawn at y = 10*i + 5 (bottom-up)
    axd.set_ylim(10 * len(order), 0); axd.axis("off")   # flip so leaf 0 is at the top, matching heatmap row 0
    from matplotlib.colors import ListedColormap
    axc.imshow(np.array([[classes.index(cls[i])] for i in order]), aspect="auto",
               cmap=ListedColormap([CLASS_COL[c] for c in classes]), vmin=-0.5, vmax=len(classes) - 0.5)
    axc.axis("off")
    hm = axh.imshow(np.clip(Z[order], -3, 3), aspect="auto", cmap="RdBu_r", vmin=-3, vmax=3,
                    interpolation="nearest")
    axh.set_yticks(range(20)); axh.yaxis.tick_right()
    axh.set_yticklabels([f"{letters[i]} ({df['Amino_Acid'][i]})" for i in order], fontsize=8.5)
    axh.set_xticks([]); axh.set_xlabel("Descriptors (6,977 columns, z-scored; values clipped at ±3)")
    cb = fig.colorbar(hm, cax=axcb, orientation="horizontal"); cb.set_label("z-score", fontsize=8); cb.ax.xaxis.set_label_position("top")
    cb.ax.tick_params(labelsize=7)
    fig.legend(handles=[Patch(fc=CLASS_COL[c], ec="k", label=pretty(c)) for c in classes],
               loc="upper right", bbox_to_anchor=(0.99, 0.985), ncol=3, fontsize=8, title="Physicochemical class",
               title_fontsize=8, frameon=False)
    save(fig, figdir, "Figure3_dendrogram_heatmap")

    # ---------------- Figure 4: t-SNE and classical MDS ----------------------
    em = pd.read_csv(res / "embeddings.csv")
    fig, axs = plt.subplots(1, 2, figsize=(11, 4.6))
    for ax, (c1, c2, t) in zip(axs, [("tSNE1", "tSNE2", "t-SNE (perplexity = 5)"), ("MDS1", "MDS2", "Classical MDS")]):
        p = em[[c1, c2]].to_numpy(); rng = np.ptp(p, axis=0).max()
        p = declutter(p, 0.045 * rng)
        label_points(ax, p[:, 0], p[:, 1], letters, colors, size=170)
        ax.set_title(t); ax.set_xlabel(f"{t.split(' ')[0]} dimension 1"); ax.set_ylabel(f"{t.split(' ')[0]} dimension 2")
    axs[1].set_xlabel("MDS dimension 1"); axs[1].set_ylabel("MDS dimension 2")
    fig.legend(handles=class_legend(classes), loc="lower center", ncol=5, fontsize=9, frameon=False,
               bbox_to_anchor=(0.5, -0.06))
    save(fig, figdir, "Figure4_tSNE_MDS")

    # ---------------- Figure 5: consensus matrix -----------------------------
    K = pd.read_csv(res / "consensus_matrix.csv", index_col=0).loc[STD_ORDER, STD_ORDER]
    fig, ax = plt.subplots(figsize=(8, 7))
    im = ax.imshow(K.values, cmap="RdYlBu_r", vmin=0, vmax=1)
    ax.set_xticks(range(20)); ax.set_xticklabels(STD_ORDER); ax.set_yticks(range(20)); ax.set_yticklabels(STD_ORDER)
    for i in range(20):
        for j in range(20):
            v = K.values[i, j]
            ax.text(j, i, f"{v:.2f}".lstrip("0") if v < 1 else "1", ha="center", va="center", fontsize=5.5,
                    color="white" if (v > 0.85 or v < 0.15) else "black")
    cb = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.03); cb.set_label("Consensus (proportion co-clustered)")
    ax.set_title("Bootstrap consensus: 100 iterations, 80% subsampling,\naverage linkage / Manhattan distance, k = 2",
                 fontsize=10)
    save(fig, figdir, "Figure5_consensus")

    # ---------------- supervised results -------------------------------------
    rr = pd.read_csv(res / "results_real.csv", index_col=0)
    rn = pd.read_csv(res / "results_null.csv", index_col=0)
    ok = rr.index[rr["N_Valid_Folds"] > 0]
    rr, rn = rr.loc[ok], rn.loc[ok]
    order_ba = rr["Balanced_Accuracy"].sort_values(ascending=False).index
    partial = rr.index[rr["N_Valid_Folds"] < 20]

    # ---------------- Figure 6: real vs seed-42 null vs 100-seed null ----------
    ms_path = res / "multiseed_null_long.csv"
    ms = pd.read_csv(ms_path) if ms_path.exists() else None
    fig, ax = plt.subplots(figsize=(8, 10.5))
    ypos = np.arange(len(order_ba))[::-1]
    if ms is not None:
        data = [ms.loc[ms.Model == m, "Balanced_Accuracy"].values for m in order_ba]
        bp = ax.boxplot(data, positions=ypos, vert=False, widths=0.6, patch_artist=True, showfliers=False,
                        whis=(5, 95), zorder=2)
        for b in bp["boxes"]:
            b.set(facecolor="#F3C9C6", edgecolor="#C8403B", lw=0.8)
        for k_ in ("whiskers", "caps", "medians"):
            for l_ in bp[k_]:
                l_.set(color="#C8403B", lw=0.8)
    ax.scatter(rn.loc[order_ba, "Balanced_Accuracy"], ypos, marker="D", s=26, c=NULL_C, zorder=4,
               label="Null control, seed 42")
    ax.scatter(rr.loc[order_ba, "Balanced_Accuracy"], ypos, marker="o", s=48, c=REAL_C, edgecolors="k",
               lw=0.5, zorder=5, label="Real descriptors (6,977 columns, PCA-19 per fold)")
    ax.axvline(0.2, ls="--", c="k", lw=1, label="Chance (1/5)")
    ax.set_yticks(ypos)
    ax.set_yticklabels([m + (" †" if m in partial else "") for m in order_ba], fontsize=8.5)
    ax.set_xlabel("LOOCV balanced accuracy"); ax.set_xlim(-0.02, 0.75)
    hand, lab = ax.get_legend_handles_labels()
    if ms is not None:
        hand.append(Patch(fc="#F3C9C6", ec="#C8403B", label="Null control, 100 seeds (box: IQR; whiskers: 5th-95th pct)"))
    ax.legend(handles=hand, loc="upper center", bbox_to_anchor=(0.42, -0.06), ncol=2, fontsize=8, frameon=False)
    save(fig, figdir, "Figure6_real_vs_null")

    # ---------------- Figure 7: confusion matrices ---------------------------
    oof_r, oof_n = np.load(res / "oof_real.npz"), np.load(res / "oof_null.npz")
    best_r = rr.sort_values(["Balanced_Accuracy", "MCC"], ascending=False).index[0]
    best_n = rn.sort_values(["Balanced_Accuracy", "MCC"], ascending=False).index[0]
    json.dump({"best_real": best_r, "best_null": best_n}, open(res / "best_models.json", "w"))
    fig, axs = plt.subplots(1, 2, figsize=(12.5, 5.0)); fig.subplots_adjust(wspace=0.55)
    labs = [pretty(c) for c in classes]
    for ax, oof, m, t in [(axs[0], oof_r, best_r, "Real descriptors"), (axs[1], oof_n, best_n, "Null control (seed 42)")]:
        cm = confusion_matrix(y, oof[f"{m}__pred"], labels=list(range(len(classes))))
        ax.imshow(cm, cmap="Blues", vmin=0, vmax=7)
        for i in range(5):
            for j in range(5):
                ax.text(j, i, cm[i, j], ha="center", va="center", color="white" if cm[i, j] > 3.5 else "black")
        ax.set_xticks(range(5)); ax.set_xticklabels(labs, rotation=35, ha="right", fontsize=8)
        ax.set_yticks(range(5)); ax.set_yticklabels(labs, fontsize=8)
        ax.set_xlabel("Predicted class"); ax.set_ylabel("True class"); ax.set_title(f"{t}\n{m}", fontsize=10)
        ax.spines[:].set_visible(False)
    save(fig, figdir, "Figure7_confusion")

    # ---------------- Figure 8: ROC ------------------------------------------
    P = oof_r[f"{best_r}__proba"]
    fig, ax = plt.subplots(figsize=(6.4, 5.4))
    aucs = {}
    for c_i, c in enumerate(classes):
        fpr, tpr, _ = roc_curve((y == c_i).astype(int), P[:, c_i]); aucs[c] = auc(fpr, tpr)
        ax.plot(fpr, tpr, c=CLASS_COL[c], lw=1.8, label=f"{pretty(c)} (AUC = {aucs[c]:.2f})")
    ax.plot([0, 1], [0, 1], "--", c="0.5")
    ax.set_xlabel("False positive rate"); ax.set_ylabel("True positive rate")
    ax.set_title(f"{best_r}: out-of-fold one-vs-rest ROC (macro AUC = {rr.loc[best_r,'ROC_AUC_Macro_OVR']:.4f})", fontsize=9.5)
    ax.legend(loc="lower right", fontsize=8.5)
    json.dump(aucs, open(res / "classwise_auc_best.json", "w"), indent=1)
    save(fig, figdir, "Figure8_ROC")

    # ---------------- Figure 9: RF importance --------------------------------
    imp = pd.read_csv(res / "rf_importance_top20.csv").fillna("")
    lab9 = [f"{r.descriptor}  [{r.block}{', ' + r.stat if r.stat else ''}]" for r in imp.itertuples()]
    blk_col = {"4D": "#3F9E4D", "3D": "#3E6DB5", "2D": "#E07B39", "2D-FP": "#E0B339", "1D": "#8E6BB8", "Graph": "#C8403B"}
    fig, ax = plt.subplots(figsize=(7.2, 6.6))
    yy = np.arange(len(imp))[::-1]
    ax.barh(yy, imp["importance"], xerr=imp["sd_over_seeds"], color=[blk_col[b] for b in imp["block"]],
            error_kw=dict(lw=0.8, capsize=2, ecolor="0.3"))
    ax.set_yticks(yy); ax.set_yticklabels(lab9, fontsize=8.5)
    ax.set_xlabel("Gini importance (mean decrease in impurity, normalised; mean ± SD over 10 seeds)")
    present = [b for b in ["1D", "2D", "2D-FP", "3D", "4D", "Graph"] if b in set(imp["block"])]
    ax.legend(handles=[Patch(fc=blk_col[b], label=f"{b} block") for b in present], loc="lower right", fontsize=8.5)
    save(fig, figdir, "Figure9_RF_importance")

    # ---------------- Figure 10: radar ---------------------------------------
    top5 = order_ba[:5]
    mets = ["Accuracy", "Balanced_Accuracy", "F1_Macro", "MCC", "Cohen_Kappa", "Precision_Macro"]
    ang = np.linspace(0, 2 * np.pi, len(mets), endpoint=False).tolist(); ang += ang[:1]
    fig = plt.figure(figsize=(7, 6.4)); ax = fig.add_subplot(111, polar=True)
    pal = ["#1B9E77", "#D95F02", "#7570B3", "#E7298A", "#66A61E"]
    for m, c in zip(top5, pal):
        v = [rr.loc[m, k] if k not in ("MCC", "Cohen_Kappa") else (rr.loc[m, k] + 1) / 2 for k in mets]
        v += v[:1]; ax.plot(ang, v, c=c, lw=1.8, label=m); ax.fill(ang, v, c=c, alpha=0.06)
    ax.set_xticks(ang[:-1]); ax.set_xticklabels(["Accuracy", "Balanced\naccuracy", "F1 (macro)", "MCC\n(rescaled)",
                                                 "Cohen's kappa\n(rescaled)", "Precision\n(macro)"], fontsize=9)
    ax.set_ylim(0, 1); ax.set_yticks([0.2, 0.4, 0.6, 0.8, 1.0]); ax.tick_params(axis="y", labelsize=7)
    ax.legend(loc="upper right", bbox_to_anchor=(1.32, 1.12), fontsize=8.5)
    save(fig, figdir, "Figure10_radar")

    # ---------------- Figure 11: fit times -----------------------------------
    o = rr["Mean_Fit_Time_ms"].sort_values(ascending=True).index
    fig, ax = plt.subplots(figsize=(7.5, 10))
    yy = np.arange(len(o))
    ax.barh(yy + 0.2, rr.loc[o, "Mean_Fit_Time_ms"], 0.4, color=REAL_C, label="Real descriptors")
    ax.barh(yy - 0.2, rn.loc[o, "Mean_Fit_Time_ms"], 0.4, color=NULL_C, label="Null control (seed 42)")
    ax.set_xscale("log"); ax.set_yticks(yy); ax.set_yticklabels(o, fontsize=8.5)
    ax.set_xlabel("Mean fit time per LOOCV fold (ms, log scale)"); ax.legend(loc="lower right")
    save(fig, figdir, "Figure11_fit_time")

    # ---------------- Figure 12: metric heatmap ------------------------------
    hm_m = ["Accuracy", "Balanced_Accuracy", "Precision_Macro", "Recall_Macro", "F1_Macro", "F1_Weighted",
            "MCC", "Cohen_Kappa", "Jaccard_Macro", "ROC_AUC_Macro_OVR", "Top2_Accuracy"]
    H = rr.loc[order_ba, hm_m].astype(float)
    fig, ax = plt.subplots(figsize=(9, 11))
    im = ax.imshow(np.ma.masked_invalid(H.values), cmap="viridis", vmin=-0.1, vmax=1, aspect="auto")
    for i in range(H.shape[0]):
        for j in range(H.shape[1]):
            v = H.values[i, j]
            if not np.isnan(v):
                ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=6.5, color="white" if v < 0.55 else "black")
    ax.set_xticks(range(len(hm_m))); ax.set_xticklabels([m.replace("_", " ") for m in hm_m], rotation=45, ha="right", fontsize=8.5)
    ax.set_yticks(range(len(H))); ax.set_yticklabels([m + (" †" if m in partial else "") for m in H.index], fontsize=8)
    fig.colorbar(im, ax=ax, fraction=0.04, pad=0.02, label="Metric value")
    save(fig, figdir, "Figure12_metric_heatmap")
    print("Figures written to", figdir.resolve())


if __name__ == "__main__":
    main()
